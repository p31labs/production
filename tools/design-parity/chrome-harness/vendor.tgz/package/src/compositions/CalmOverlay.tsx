import React from 'react';

export interface CalmOverlayProps {
  /** Current spoon level; the overlay renders only when spoons === 0. */
  spoons: number;
  /** Return handler (consumer restores spoons / navigates away). */
  onReturn: () => void;
  className?: string;
}

/** CalmOverlay — shown at spoon level 0. Motion pauses, breathing circle rest stop.
 *  Store-agnostic: `spoons` + `onReturn` are props; the consumer owns the store. */
export function CalmOverlay({ spoons, onReturn, className = '' }: CalmOverlayProps) {
  if (spoons !== 0) return null;

  return (
    <div className={`calm-overlay ${className}`.trim()} role="dialog" aria-modal="true" aria-label="Calm mode">
      <div className="calm-circle" />
      <h1>Take a breath.</h1>
      <p>Calm mode — everything has slowed down. You can rest here as long as you need.</p>
      <button className="btn btn-primary" type="button" onClick={onReturn}>
        Return to the workspace
      </button>
    </div>
  );
}

export default CalmOverlay;