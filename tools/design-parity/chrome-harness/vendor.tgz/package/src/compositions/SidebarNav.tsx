import React from 'react';

export interface SidebarNavItem {
  path: string;
  label: string;
  emoji?: string;
  flagship?: boolean;
}

export interface SidebarNavProps {
  /** Structured navigation items (spec). */
  items: SidebarNavItem[];
  /** Currently active path. */
  activePath?: string;
  /** Navigate handler — the consumer owns routing (react-router, etc.). */
  onNavigate?: (path: string) => void;
  className?: string;
  ariaLabel?: string;
}

/** Simple active-path match: exact, or prefix for section roots. */
export function isActivePath(path: string, current?: string): boolean {
  if (!current) return false;
  if (path === '/') return current === '/';
  return current === path || current.startsWith(path + '/');
}

/** SidebarNav — flat suite nav (emoji + label), active state per route.
 *  Store-agnostic: the consumer passes `items`, `activePath`, and `onNavigate`. */
export function SidebarNav({
  items,
  activePath,
  onNavigate,
  className = '',
  ariaLabel = 'Main navigation',
}: SidebarNavProps) {
  return (
    <nav className={`sidebar-nav ${className}`.trim()} aria-label={ariaLabel}>
      {items.map((s) => {
        const active = isActivePath(s.path, activePath);
        return (
          <button
            key={s.path}
            type="button"
            className={`sidebar-nav__item${active ? ' is-active' : ''}`}
            aria-current={active ? 'page' : undefined}
            onClick={() => onNavigate?.(s.path)}
          >
            {s.emoji && <span aria-hidden="true">{s.emoji}</span>}
            <span>{s.label}</span>
          </button>
        );
      })}
    </nav>
  );
}

export default SidebarNav;