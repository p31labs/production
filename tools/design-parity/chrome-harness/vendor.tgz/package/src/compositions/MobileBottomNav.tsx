import React from 'react';
import type { SidebarNavItem } from './SidebarNav';

export interface MobileBottomNavProps {
  /** Structured navigation items (spec); only flagships are shown. */
  items: SidebarNavItem[];
  /** Currently active path. */
  activePath?: string;
  /** Navigate handler — the consumer owns routing. */
  onNavigate?: (path: string) => void;
  className?: string;
  ariaLabel?: string;
}

/** MobileBottomNav — flagship items only (suite pattern).
 *  Store-agnostic; the consumer filters `items` to its flagships if desired. */
export function MobileBottomNav({
  items,
  activePath,
  onNavigate,
  className = '',
  ariaLabel = 'Mobile navigation',
}: MobileBottomNavProps) {
  /** Show only flagship items (the suite pattern). An item is flagship only
   *  when `flagship === true` — unset means "not a bottom-nav shortcut". */
  const show = items.filter((s) => s.flagship === true);
  return (
    <nav className={`mobile-bottom-nav ${className}`.trim()} aria-label={ariaLabel}>
      {show.map((s) => {
        const active = activePath
          ? activePath === s.path || activePath.startsWith(s.path + '/')
          : false;
        return (
          <button
            key={s.path}
            type="button"
            className="mobile-bottom-nav__btn"
            aria-label={s.label}
            aria-current={active ? 'page' : undefined}
            onClick={() => onNavigate?.(s.path)}
          >
            <span aria-hidden="true">{s.emoji}</span>
          </button>
        );
      })}
    </nav>
  );
}

export default MobileBottomNav;