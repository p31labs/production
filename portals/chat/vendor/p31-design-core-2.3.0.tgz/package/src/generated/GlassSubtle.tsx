/**
 * @file GlassSubtle — Low-opacity glass surface with subtle blur.
 * Auto-generated from components.yml.
 */

import type { ReactNode } from 'react';

export interface GlassSubtleProps {
  children: ReactNode;
  className?: string;
  style?: React.CSSProperties;
}

export function GlassSubtle({ children, className, style }: GlassSubtleProps) {
  const cls = `rounded-2xl border border-white/[0.06] backdrop-blur-xl bg-void-raised/60 shadow-[0_4px_16px_rgba(0,0,0,0.3)] ${className || ''}`;
  return <div className={cls} style={style}>{children}</div>;
}

export default GlassSubtle;
