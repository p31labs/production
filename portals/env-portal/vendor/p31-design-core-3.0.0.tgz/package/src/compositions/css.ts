import '@p31ca/design-core/css/all.css';

export {};
