import { useCallback, useRef, useState } from 'react';
import type { CSSProperties, ReactNode, PointerEvent as ReactPointerEvent, KeyboardEvent as ReactKeyboardEvent } from 'react';

export interface SplitProps {
  /** First pane content (summary, list, tree…). */
  a: ReactNode;
  /** Second pane content (focus surface, canvas, editor…). */
  b: ReactNode;
  /** Collapse pane B + handle; pane A owns the row. */
  collapsed?: boolean;
  /** Initial fraction of the container given to pane A (0.2–0.8). */
  defaultRatio?: number;
  onRatioChange?: (ratio: number) => void;
  ariaLabelA?: string;
  ariaLabelB?: string;
  className?: string;
  style?: CSSProperties;
}

const MIN_RATIO = 0.2;
const MAX_RATIO = 0.8;
const STEP = 0.05;

/**
 * Split — two panes with a draggable handle. Pointer-resized via capture;
 * keyboard: Left/Right nudge, Home/End snap. Pane B collapses on mobile.
 */
export function Split({ a, b, collapsed = false, defaultRatio = 0.5, onRatioChange, ariaLabelA, ariaLabelB, className = '', style }: SplitProps) {
  const rootRef = useRef<HTMLDivElement>(null);
  const [ratio, setRatioState] = useState(() => Math.min(MAX_RATIO, Math.max(MIN_RATIO, defaultRatio)));
  const [dragging, setDragging] = useState(false);

  const setRatio = useCallback((next: number) => {
    const clamped = Math.min(MAX_RATIO, Math.max(MIN_RATIO, next));
    setRatioState(clamped);
    onRatioChange?.(clamped);
  }, [onRatioChange]);

  const onPointerDown = (e: ReactPointerEvent<HTMLDivElement>) => {
    e.preventDefault();
    e.currentTarget.setPointerCapture(e.pointerId);
    setDragging(true);
  };
  const onPointerMove = (e: ReactPointerEvent<HTMLDivElement>) => {
    if (!dragging) return;
    const rect = rootRef.current?.getBoundingClientRect();
    if (!rect || rect.width === 0) return;
    setRatio((e.clientX - rect.left) / rect.width);
  };
  const endDrag = () => setDragging(false);
  const onKeyDown = (e: ReactKeyboardEvent<HTMLDivElement>) => {
    if (e.key === 'ArrowLeft') { e.preventDefault(); setRatio(ratio - STEP); }
    if (e.key === 'ArrowRight') { e.preventDefault(); setRatio(ratio + STEP); }
    if (e.key === 'Home') { e.preventDefault(); setRatio(MIN_RATIO); }
    if (e.key === 'End') { e.preventDefault(); setRatio(MAX_RATIO); }
  };

  const vars = { '--_split-a': `${ratio}fr`, '--_split-b': `${1 - ratio}fr` } as CSSProperties;

  return (
    <div ref={rootRef} data-p31="split" data-collapsed={collapsed ? '' : undefined} className={className} style={{ ...vars, ...style }}>
      <section data-p31="split-pane" data-side="a" aria-label={ariaLabelA}>{a}</section>
      {!collapsed && (
        <div
          data-p31="split-handle"
          data-dragging={dragging ? '' : undefined}
          role="separator"
          aria-orientation="vertical"
          aria-valuemin={Math.round(MIN_RATIO * 100)}
          aria-valuemax={Math.round(MAX_RATIO * 100)}
          aria-valuenow={Math.round(ratio * 100)}
          tabIndex={0}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
          onKeyDown={onKeyDown}
        />
      )}
      <section data-p31="split-pane" data-side="b" aria-label={ariaLabelB}>{b}</section>
    </div>
  );
}

export default Split;