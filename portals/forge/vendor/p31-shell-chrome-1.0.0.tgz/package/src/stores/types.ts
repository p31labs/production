export type { ThemeId } from '@p31/shared/theme/ids';
export type { ThemeConfig } from '@p31/shared/theme/types';
