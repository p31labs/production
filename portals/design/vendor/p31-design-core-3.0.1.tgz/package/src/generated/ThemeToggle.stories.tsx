/**
 * @file ThemeToggle.stories.tsx
 * Auto-generated Storybook stories for ThemeToggle.
 */

import type { Meta, StoryObj } from '@storybook/react';
import { ThemeToggle } from './ThemeToggle.js';

const meta: Meta<typeof ThemeToggle> = {
  title: 'Components/ThemeToggle',
  component: ThemeToggle,
  tags: ['autodocs'],
  parameters: {
    layout: 'centered',
  },
};

export default meta;
type Story = StoryObj<typeof ThemeToggle>;

export const Default: Story = {
  args: {},
};
