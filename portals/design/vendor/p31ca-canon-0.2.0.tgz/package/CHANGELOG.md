# @p31ca/canon

## 0.2.0

### Minor Changes

- Deprecate 152 unused design tokens (DTCG `$deprecated` in `deprecations.json` + merged into `tokens.dtc.json`). Add `$replacement` for 19 tokens and a `codemod-deprecated-tokens.mjs` for consumer migration. Removal in v0.3.0.
