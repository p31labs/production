/**
 * @file ThemeToggle.wc.js — Web Component (Shadow DOM) version of ThemeToggle.
 * Auto-generated from components.yml.
 *
 * Usage:
 *   <script type="module" src="./ThemeToggle.wc.js"></script>
 *   <p31-theme-toggle></p31-theme-toggle>
 *
 * Requires p31-tokens.css to be loaded (defines --p31-* variables).
 */

const template = document.createElement('template');
template.innerHTML = `
  <style>
:host {
  display: inline-flex;
    --p31-semantic-color-background-default: oklch(10% 0.01 240);
    --p31-theme-light-background-default: oklch(98% 0.003 248);
    --p31-theme-light-background-alt: oklch(100% 0 270);
    --p31-theme-light-text-primary: oklch(21% 0.04 266);
    --p31-theme-light-text-secondary: oklch(21% 0.04 266 / 0.6);
    --p31-theme-light-text-tertiary: oklch(21% 0.04 266 / 0.3);
    --p31-theme-light-glass_surface: oklch(0% 0 270 / 0.03);
    --p31-theme-light-glass_border: oklch(0% 0 270 / 0.08);
    --p31-theme-light-glass_border_hover: oklch(0% 0 270 / 0.15);
    --p31-primitive-typography-font_sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
  padding: 8px;
  border-radius: 9999px;
  background: oklch(100% 0.01 270 / 0.05);
  border: 1px solid oklch(100% 0.01 270 / 0.1);
  cursor: pointer;
  transition: border-color 0.2s ease;
}
:host(:hover) {
  border-color: oklch(0.971 0.003 286);
}

  </style>

`;

class P31ThemeToggle extends HTMLElement {
  static get observedAttributes() { return ['0', '1']; }

  constructor() {
    super();
    this.attachShadow({ mode: 'open' });
    this.shadowRoot.appendChild(template.content.cloneNode(true));
  }
  attributeChangedCallback(name, oldVal, newVal) {
    if (name === 'dark' || name === 'light') {
      const isDark = this.getAttribute('dark') !== null;
      this.textContent = isDark ? '🌙' : '☀️';
    }
  }

  connectedCallback() {
    
    
  }
}

customElements.define('p31-theme-toggle', P31ThemeToggle);
