/**
 * @file Crown — Animated tetrahedral crown brand glyph.
 * Auto-generated from components.yml.
 *
 * @a2ui-component Crown
 * @a2ui-props size "xs" | "sm" | "md" | "lg" - Display size
 * @a2ui-props brand "p31ca" | "phosphorus" | "phos" | "willow" - Brand palette
 * @a2ui-props inverted boolean - Swap accent/violet
 * @a2ui-example {"component":"Crown","size":"md","brand":"p31ca"}
 */

import type { CSSProperties } from 'react';

export interface CrownProps {
  size?: 'xs' | 'sm' | 'md' | 'lg';
  brand?: 'p31ca' | 'phosphorus' | 'phos' | 'willow';
  inverted?: boolean;
  className?: string;
  ariaLabel?: string;
}

const SIZE_MAP: Record<string, string> = {
  xs: 'w-10 h-10',
  sm: 'w-16 h-16',
  md: 'w-32 h-32',
  lg: 'w-64 h-64',
};

const ACCENT_MAP: Record<string, string> = {
  p31ca: '#00F0FF',
  phosphorus: '#10B981',
  phos: '#FBBF24',
  willow: '#34D399',
};

const ACCENT_VIOLET_MAP: Record<string, string> = {
  p31ca: '#A78BFA',
  phosphorus: '#A78BFA',
  phos: '#00F0FF',
  willow: '#FBBF24',
};

const svgContent = `
  <title>Crown</title>
  <desc>A six-pointed crown with rotating accents, lighting nodes, and a radiant central jewel. 6-color palette.</desc>
  <defs>
    <linearGradient id="crown-grad" x1="0%" y1="0%" x2="100%" y2="100%">
      <stop offset="0%" stop-color="#00F0FF" stop-opacity="0.9"/>
      <stop offset="25%" stop-color="#A78BFA" stop-opacity="0.9"/>
      <stop offset="50%" stop-color="#FBBF24" stop-opacity="0.8"/>
      <stop offset="75%" stop-color="#818CF8" stop-opacity="0.9"/>
      <stop offset="100%" stop-color="#00F0FF" stop-opacity="0.9"/>
    </linearGradient>
  </defs>
  <style>
    .cr-crown { stroke: rgba(255,255,255,0.1); stroke-width: 0.75; stroke-linejoin: round; }
    .cr-c1 { fill: var(--p31-accent, #00F0FF); }
    .cr-c2 { fill: var(--p31-accent-violet, #A78BFA); }
    .cr-c3 { fill: var(--p31-accent-gold, #FBBF24); }
    .cr-c4 { fill: var(--p31-accent-green, #34D399); }
    .cr-c5 { fill: var(--p31-accent-iris, #818CF8); }
    .cr-c6 { fill: var(--p31-accent-red, #FB7185); }
    .cr-master { transition: filter 0.6s ease-in-out, opacity 0.6s ease-in-out; }
    .cr-jewel { filter: drop-shadow(0 0 4px currentColor); transform-origin: 100px 100px; }
    .cr-j1 { animation: crOrbit 16s infinite linear; }
    .cr-j3 { animation: crOrbit 16s infinite linear; animation-delay: -5.33s; }
    .cr-j5 { animation: crOrbit 16s infinite linear; animation-delay: -10.67s; }
    .cr-core { fill: var(--p31-accent, #00F0FF); transform-origin: 100px 100px; animation: crCore 3s infinite alternate ease-in-out; }
    .cr-band { fill: none; stroke-width: 1.5; stroke-linecap: round; }
    .cr-ring { fill: none; stroke-width: 1; opacity: 0.2; transform-origin: 100px 100px; }
    .cr-b1 { stroke: var(--p31-accent, #00F0FF); animation: crBand 8s infinite linear; }
    .cr-b2 { stroke: var(--p31-accent-violet, #A78BFA); animation: crBand 8s infinite linear reverse; }
    .cr-b3 { stroke: var(--p31-accent-gold, #FBBF24); animation: crBand 8s infinite linear; }
    @keyframes crOrbit { to { transform: rotate(360deg); } }
    @keyframes crCore { 0% { transform: scale(0.85); filter: drop-shadow(0 0 4px var(--p31-accent, #00F0FF)); } 100% { transform: scale(1.1); filter: drop-shadow(0 0 20px var(--p31-accent, #00F0FF)); } }
    @keyframes crBand { to { stroke-dashoffset: 400; } }
    .cr-rotate { transform-origin: 100px 100px; animation: crRotate 30s infinite linear; }
    @keyframes crRotate { to { transform: rotate(360deg); } }
    .master-pulse .cr-master { filter: drop-shadow(0 0 22px var(--p31-accent, #00F0FF)) !important; opacity: 1 !important; }
    @media (prefers-reduced-motion: reduce) { .cr-rotate, .cr-jewel, .cr-core, .cr-ring, .cr-band { animation: none; } .cr-core { r: 14; opacity: 0.9; } }
  </style>
  <g>
    <path d="M 40 155 Q 60 80 70 38 Q 85 18 100 19 Q 115 18 130 38 Q 140 80 160 155" class="cr-crown" fill="none" stroke="url(#crown-grad)" stroke-width="2.5"/>
    <path d="M 40 155 Q 60 80 70 38 Q 85 18 100 19 Q 115 18 130 38 Q 140 80 160 155 Q 145 145 130 142 Q 115 139 100 139 Q 85 139 70 142 Q 55 145 40 155 Z" fill="rgba(255,255,255,0.04)"/>
    <polygon points="100,19 108,38 128,38" class="cr-c1"/>
    <polygon points="100,19 92,38 72,38" class="cr-c2"/>
    <polygon points="70,38 78,55 92,38" class="cr-c3"/>
    <polygon points="130,38 122,55 108,38" class="cr-c4"/>
    <polygon points="72,38 85,60 100,58 92,38" class="cr-c5"/>
    <polygon points="128,38 115,60 100,58 108,38" class="cr-c6"/>
    <polygon points="100,52 108,70 100,82" class="cr-c1" opacity="0.7"/>
    <polygon points="100,52 92,70 100,82" class="cr-c2" opacity="0.7"/>
  </g>
  <g class="cr-rotate">
    <circle cx="100" cy="100" r="88" fill="none" stroke="rgba(255,255,255,0.04)" stroke-width="1"/>
    <circle cx="100" cy="100" r="75" class="cr-band cr-b1" stroke-dasharray="60 30"/>
    <circle cx="100" cy="100" r="72" class="cr-band cr-b2" stroke-dasharray="30 60"/>
    <circle cx="100" cy="100" r="68" class="cr-band cr-b3" stroke-dasharray="50 50"/>
    <circle cx="100" cy="38" r="4.5" class="cr-jewel cr-j1 cr-c3"/>
    <circle cx="130" cy="38" r="3.5" class="cr-jewel cr-j3 cr-c6"/>
    <circle cx="144" cy="75" r="3" class="cr-jewel cr-j5 cr-c4"/>
    <circle cx="100" cy="100" r="16" class="cr-core cr-master"/>
    <circle cx="100" cy="100" r="11" fill="none" stroke="var(--p31-accent-violet, #A78BFA)" stroke-width="1" opacity="0.5">
      <animate attributeName="r" from="11" to="14" dur="1.5s" repeatCount="indefinite"/>
      <animate attributeName="opacity" from="0.5" to="0.2" dur="1.5s" repeatCount="indefinite"/>
    </circle>
    <circle cx="100" cy="100" r="5" fill="var(--p31-bg, #0A0A0F)" opacity="0.9"/>
  </g>
`;

/**
 * The viewBox Y offset (16) vertically centres the jewel cavity
 * (at ~100px) within the total glyph height (200px), leaving balanced
 * breathing room above the crown peaks and below the lowest arc.
 */
export function Crown({ size = 'md', brand = 'p31ca', inverted = false, className = '', ariaLabel = 'P31 Crown animated icon' }: CrownProps) {
  const primary = ACCENT_MAP[brand];
  const secondary = ACCENT_VIOLET_MAP[brand];
  const sizeClass = SIZE_MAP[size];

  const innerStyle: CSSProperties & Record<string, string> = inverted
    ? { '--p31-accent': secondary, '--p31-accent-violet': primary }
    : { '--p31-accent': primary, '--p31-accent-violet': secondary };

  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      viewBox="0 16 200 168"
      width="100%"
      height="100%"
      role="img"
      aria-label={ariaLabel}
      className={`overflow-visible drop-shadow-2xl ${sizeClass} ${className || ''}`}
      style={innerStyle}
      dangerouslySetInnerHTML={{ __html: svgContent }}
    />
  );
}

export default Crown;
